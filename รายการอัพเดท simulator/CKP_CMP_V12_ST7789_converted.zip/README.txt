Converted from uploaded V12 main.py for ST7789 320x240.
Keep the working st7789_pico.py and xpt2046_pico.py.
