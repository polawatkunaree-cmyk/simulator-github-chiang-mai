Final CKP CMP V12 ST7789 package
Files:
- main.py
- st7789_pico.py
- xpt2046_pico.py

Upload all three files together.
