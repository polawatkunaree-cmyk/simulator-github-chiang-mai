from micropython import const
import framebuf
from time import sleep_ms

BLACK = const(0x0000)
WHITE = const(0xFFFF)
RED = const(0xF800)
GREEN = const(0x07E0)
BLUE = const(0x001F)
CYAN = const(0x07FF)
YELLOW = const(0xFFE0)
GRAY = const(0x8410)


class ST7789(framebuf.FrameBuffer):
    def __init__(self, spi, cs, dc, reset, rotation=1):
        self.spi = spi
        self.cs = cs
        self.dc = dc
        self.reset = reset
        self.rotation = rotation
        self.width = 320 if rotation in (1, 3) else 240
        self.height = 240 if rotation in (1, 3) else 320
        self.buffer = bytearray(self.width * self.height * 2)
        super().__init__(self.buffer, self.width, self.height, framebuf.RGB565)
        self._reset()
        self._init_display()

    def _write(self, command, data=None):
        self.spi.init(baudrate=20_000_000, polarity=0, phase=0)
        self.cs(0)
        self.dc(0)
        self.spi.write(bytes((command,)))
        if data is not None:
            self.dc(1)
            self.spi.write(data)
        self.cs(1)

    def _reset(self):
        self.reset(1)
        sleep_ms(20)
        self.reset(0)
        sleep_ms(20)
        self.reset(1)
        sleep_ms(120)

    def _init_display(self):
        self._write(0x01)
        sleep_ms(150)
        self._write(0x11)
        sleep_ms(150)
        self._write(0x3A, b"\x05")       # RGB565
        # MV/MX/MY set rotation; BGR matches the common red 2.8-inch module.
        madctl = (0x00, 0x60, 0xC0, 0xA0)[self.rotation] | 0x08
        self._write(0x36, bytes((madctl,)))
        self._write(0x21)                 # inversion on for common red PCB module
        self._write(0x29)
        sleep_ms(100)

    def _window(self, x0, y0, x1, y1):
        # Full-size 240 x 320 ST7789 panels use zero RAM offsets.
        self._write(0x2A, bytes((x0 >> 8, x0 & 0xFF, x1 >> 8, x1 & 0xFF)))
        self._write(0x2B, bytes((y0 >> 8, y0 & 0xFF, y1 >> 8, y1 & 0xFF)))
        self._write(0x2C)

    def show(self):
        self.spi.init(baudrate=20_000_000, polarity=0, phase=0)
        self._window(0, 0, self.width - 1, self.height - 1)
        self.cs(0)
        self.dc(1)
        # framebuf stores each RGB565 pixel little-endian; TFT expects MSB first.
        chunk = bytearray(512)
        view = memoryview(self.buffer)
        for start in range(0, len(self.buffer), len(chunk)):
            source = view[start:start + len(chunk)]
            n = len(source)
            for i in range(0, n, 2):
                chunk[i] = source[i + 1]
                chunk[i + 1] = source[i]
            self.spi.write(memoryview(chunk)[:n])
        self.cs(1)
