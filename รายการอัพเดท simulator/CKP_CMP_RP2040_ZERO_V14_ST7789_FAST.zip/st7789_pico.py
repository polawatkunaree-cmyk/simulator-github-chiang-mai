import micropython
from micropython import const
import framebuf
from time import sleep_ms

BLACK = const(0x0000)
WHITE = const(0xFFFF)
RED = const(0xF800)
GREEN = const(0x07E0)
BLUE = const(0x001F)
CYAN = const(0x07FF)
YELLOW = const(0xFFE0)
GRAY = const(0x8410)
MAGENTA = const(0xF81F)

# V14 speed-up: ST7789 normally accepts a much faster SPI clock than the
# conservative V13 setting. 40 MHz is a good balance for RP2040 + jumper wires.
TFT_BAUDRATE = const(40_000_000)


@micropython.viper
def _swap_rgb565_bytes(buf, length: int):
    """Swap RGB565 byte order in-place using native Viper code.

    framebuf.RGB565 is little-endian in RAM while ST7789 expects MSB first.
    V13 did this swap in a Python loop for every pixel; that was the main
    reason a 320x240 refresh felt slow. Viper makes the same operation native.
    """
    p = ptr8(buf)
    i = 0
    while i < length:
        a = p[i]
        p[i] = p[i + 1]
        p[i + 1] = a
        i += 2


class ST7789(framebuf.FrameBuffer):
    """Fast ST7789 240x320 driver for RP2040 MicroPython.

    rotation=1 gives 320x240 landscape.
    V14 keeps the full framebuffer used by the working V13 build, but removes
    the slow per-pixel Python conversion from show().
    """

    def __init__(self, spi, cs, dc, reset, rotation=1):
        self.spi = spi
        self.cs = cs
        self.dc = dc
        self.reset = reset
        self.rotation = rotation & 3

        if self.rotation in (1, 3):
            self.width = 320
            self.height = 240
        else:
            self.width = 240
            self.height = 320

        self.buffer = bytearray(self.width * self.height * 2)
        super().__init__(self.buffer, self.width, self.height, framebuf.RGB565)

        self._reset()
        self._init_display()

    def _spi_tft(self):
        # XPT2046 temporarily lowers the shared bus to 1 MHz. Restore the TFT
        # clock only when we are about to talk to the display.
        self.spi.init(baudrate=TFT_BAUDRATE, polarity=0, phase=0)

    def _write(self, command, data=None):
        self._spi_tft()
        self.cs(0)
        self.dc(0)
        self.spi.write(bytes((command,)))
        if data is not None:
            self.dc(1)
            self.spi.write(data)
        self.cs(1)

    def _reset(self):
        self.reset(1)
        sleep_ms(50)
        self.reset(0)
        sleep_ms(50)
        self.reset(1)
        sleep_ms(150)

    def _init_display(self):
        self._write(0x01)                 # SWRESET
        sleep_ms(150)
        self._write(0x11)                 # SLPOUT
        sleep_ms(120)
        self._write(0x3A, b"\x55")        # 16-bit RGB565
        madctl = (0x00, 0x60, 0xC0, 0xA0)[self.rotation]
        self._write(0x36, bytes((madctl,)))
        self._write(0x21)                 # INVON - tested panel
        self._write(0x29)                 # DISPON
        sleep_ms(100)

    def _window(self, x0, y0, x1, y1):
        self._write(0x2A, bytes(((x0 >> 8) & 0xFF, x0 & 0xFF,
                                 (x1 >> 8) & 0xFF, x1 & 0xFF)))
        self._write(0x2B, bytes(((y0 >> 8) & 0xFF, y0 & 0xFF,
                                 (y1 >> 8) & 0xFF, y1 & 0xFF)))
        self._write(0x2C)

    def show(self):
        """Push the complete 320x240 framebuffer quickly."""
        self._spi_tft()
        self._window(0, 0, self.width - 1, self.height - 1)

        n = len(self.buffer)
        _swap_rgb565_bytes(self.buffer, n)
        self.cs(0)
        self.dc(1)
        self.spi.write(self.buffer)
        self.cs(1)
        _swap_rgb565_bytes(self.buffer, n)
