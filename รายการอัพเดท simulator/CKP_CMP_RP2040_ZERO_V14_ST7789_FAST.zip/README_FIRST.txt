CKP/CMP RP2040 ZERO - V14 FAST ST7789 2.8 inch
================================================

This build is based on the working V13 320x240 version.
No CKP/CMP pattern logic, pin assignment, or touch calibration was intentionally changed.

V14 display speed changes:
1. TFT SPI increased from 20 MHz to 40 MHz.
2. RGB565 byte swapping moved from a slow Python per-pixel loop to MicroPython Viper native code.
3. RPM +/- and hold-repeat no longer rebuild every button; only the RPM area is rebuilt before refresh.

Upload these 3 files to the RP2040 Zero:
- main.py
- st7789_pico.py
- xpt2046_pico.py

You can overwrite the V13 files. Keep your existing touch_cal_st7789_v13.json if it is already calibrated correctly.
Then Hard Reset the board.

If the screen becomes unstable, shows random pixels, or stays white with your particular wiring,
change TFT_BAUDRATE in st7789_pico.py from 40_000_000 to 30_000_000 and change the first
SPI baudrate in main.py to 30_000_000 as well.
