from micropython import const
import framebuf
from time import sleep_ms

BLACK=const(0x0000); WHITE=const(0xFFFF); RED=const(0xF800)
GREEN=const(0x07E0); BLUE=const(0x001F); CYAN=const(0x07FF)
YELLOW=const(0xFFE0); GRAY=const(0x8410)

class ST7789(framebuf.FrameBuffer):
    def __init__(self, spi, cs, dc, reset, rotation=1):
        self.spi=spi; self.cs=cs; self.dc=dc; self.reset=reset
        self.width=320
        self.height=240
        self.buffer=bytearray(self.width*self.height*2)
        super().__init__(self.buffer,self.width,self.height,framebuf.RGB565)
        self._reset()
        self._init_display()

    def _write(self, cmd, data=None):
        self.cs(0); self.dc(0); self.spi.write(bytes([cmd]))
        if data:
            self.dc(1); self.spi.write(data)
        self.cs(1)

    def _reset(self):
        self.reset(1); sleep_ms(50)
        self.reset(0); sleep_ms(50)
        self.reset(1); sleep_ms(150)

    def _init_display(self):
        self._write(0x01); sleep_ms(150)
        self._write(0x11); sleep_ms(120)
        self._write(0x3A,b'\x55')
        self._write(0x36,b'\x60')
        self._write(0x21)
        self._write(0x29); sleep_ms(100)

    def _window(self,x0,y0,x1,y1):
        self._write(0x2A,bytes([x0>>8,x0&255,x1>>8,x1&255]))
        self._write(0x2B,bytes([y0>>8,y0&255,y1>>8,y1&255]))
        self._write(0x2C)

    def show(self):
        self._window(0,0,319,239)
        self.cs(0); self.dc(1)
        out=bytearray(len(self.buffer))
        for i in range(0,len(self.buffer),2):
            out[i]=self.buffer[i+1]
            out[i+1]=self.buffer[i]
        self.spi.write(out)
        self.cs(1)
