from micropython import const
import framebuf
from time import sleep_ms

BLACK = const(0x0000)
WHITE = const(0xFFFF)
RED = const(0xF800)
GREEN = const(0x07E0)
BLUE = const(0x001F)
CYAN = const(0x07FF)
YELLOW = const(0xFFE0)
GRAY = const(0x8410)
MAGENTA = const(0xF81F)


class ST7789(framebuf.FrameBuffer):
    """ST7789 240x320 driver for RP2040 MicroPython.

    rotation=1 gives 320x240 landscape.
    This version uses the full frame buffer because the RP2040-Zero test
    panel has already been confirmed to work with a 320x240 buffer.
    """

    def __init__(self, spi, cs, dc, reset, rotation=1):
        self.spi = spi
        self.cs = cs
        self.dc = dc
        self.reset = reset
        self.rotation = rotation & 3

        if self.rotation in (1, 3):
            self.width = 320
            self.height = 240
        else:
            self.width = 240
            self.height = 320

        self.buffer = bytearray(self.width * self.height * 2)
        super().__init__(
            self.buffer,
            self.width,
            self.height,
            framebuf.RGB565,
        )

        self._reset()
        self._init_display()

    def _spi_tft(self):
        # Touch temporarily lowers the shared SPI bus to 1 MHz.
        # Restore TFT speed before every TFT transfer.
        self.spi.init(
            baudrate=20_000_000,
            polarity=0,
            phase=0,
        )

    def _write(self, command, data=None):
        self._spi_tft()
        self.cs(0)
        self.dc(0)
        self.spi.write(bytes((command,)))
        if data is not None:
            self.dc(1)
            self.spi.write(data)
        self.cs(1)

    def _reset(self):
        self.reset(1)
        sleep_ms(50)
        self.reset(0)
        sleep_ms(50)
        self.reset(1)
        sleep_ms(150)

    def _init_display(self):
        self._write(0x01)                 # SWRESET
        sleep_ms(150)
        self._write(0x11)                 # SLPOUT
        sleep_ms(120)
        self._write(0x3A, b"\x55")        # 16-bit RGB565

        # Rotation values for a full-size 240x320 ST7789 panel.
        madctl = (0x00, 0x60, 0xC0, 0xA0)[self.rotation]
        self._write(0x36, bytes((madctl,)))

        self._write(0x21)                 # INVON - matches tested 2.8" panel
        self._write(0x29)                 # DISPON
        sleep_ms(100)

    def _window(self, x0, y0, x1, y1):
        # 2.8" 240x320 panel uses zero RAM offsets.
        self._write(
            0x2A,
            bytes((
                (x0 >> 8) & 0xFF, x0 & 0xFF,
                (x1 >> 8) & 0xFF, x1 & 0xFF,
            )),
        )
        self._write(
            0x2B,
            bytes((
                (y0 >> 8) & 0xFF, y0 & 0xFF,
                (y1 >> 8) & 0xFF, y1 & 0xFF,
            )),
        )
        self._write(0x2C)

    def show(self):
        self._spi_tft()
        self._window(0, 0, self.width - 1, self.height - 1)
        self.cs(0)
        self.dc(1)

        # MicroPython framebuf RGB565 bytes are little-endian while ST7789
        # receives each pixel MSB first. Swap in chunks without allocating
        # another full-screen buffer.
        chunk = bytearray(512)
        source_view = memoryview(self.buffer)

        for start in range(0, len(self.buffer), len(chunk)):
            source = source_view[start:start + len(chunk)]
            n = len(source)
            for i in range(0, n, 2):
                chunk[i] = source[i + 1]
                chunk[i + 1] = source[i]
            self.spi.write(memoryview(chunk)[:n])

        self.cs(1)
