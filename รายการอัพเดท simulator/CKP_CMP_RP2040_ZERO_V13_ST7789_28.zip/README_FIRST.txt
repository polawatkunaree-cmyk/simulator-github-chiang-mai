CKP/CMP Simulator V13 - ST7789 2.8 inch (320 x 240 landscape)

THIS PACKAGE IS BASED ON THE WORKING V12 SIGNAL GENERATOR.
CKP/CMP PIO generation and Isuzu pattern data were not changed.
Only the display/touch layer and 320x240 UI were changed.

DISPLAY
- ST7789 2.8 inch, native 240 x 320
- Landscape UI: 320 x 240
- XPT2046 resistive touch
- SPI shared between TFT and touch

RP2040-Zero wiring used by this version
- GPIO0  -> T_DO
- GPIO1  -> TFT CS
- GPIO2  -> TFT SCK + T_CLK
- GPIO3  -> TFT MOSI/SDI + T_DIN
- GPIO4  -> TFT DC/A0
- GPIO5  -> TFT RESET
- GPIO6  -> T_CS
- GPIO7  -> T_IRQ
- GPIO14 -> CMP
- GPIO15 -> CKP

Touch defaults are based on the raw values measured on 2026-09-23:
LT (680,427)
RT (560,3635)
LB (3087,551)
RB (3511,3583)
CENTER (1971,1897)

IMPORTANT FOR FIRST TEST
1. Delete the old files from the RP2040-Zero.
2. Upload ONLY:
   main.py
   st7789_pico.py
   xpt2046_pico.py
3. Do NOT upload st7735_pico.py.
4. Old touch_cal_v2.json is not used by this version.
5. Hard reset the RP2040-Zero.
6. The first screen should fill the complete 320x240 display.
7. If MicroPico stops main.py when opening REPL, hard-reset once and do not
   press Run again; main.py starts automatically after reset.

TOUCH
This test build uses the measured 2.8-inch touch values immediately.
If the display is correct but touch is offset, report which button you touch
and which button reacts. We can then fine-tune the mapping without changing
the CKP/CMP generator.

Version: V13_ST7789_28_FULLSCREEN
