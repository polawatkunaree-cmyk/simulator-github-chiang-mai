
# CKP CMP V12 ST7789 UI SCALE TEST
# Keep st7789_pico.py and xpt2046_pico.py from the working version

from machine import Pin, SPI
from st7789_pico import ST7789, BLACK, WHITE, RED, GREEN, BLUE, YELLOW

spi = SPI(0, baudrate=10000000, polarity=0, phase=0,
          sck=Pin(2), mosi=Pin(3))

tft = ST7789(
    spi,
    cs=Pin(1, Pin.OUT, value=1),
    dc=Pin(4, Pin.OUT, value=0),
    reset=Pin(5, Pin.OUT, value=1),
    rotation=1
)

# 320x240 layout
tft.fill(BLACK)

tft.text("PATTERN", 110, 20, YELLOW)
tft.text("60-2", 130, 60, WHITE)

# large buttons
tft.fill_rect(20,160,80,45,BLUE)
tft.fill_rect(120,160,80,45,GREEN)
tft.fill_rect(220,160,80,45,RED)

tft.text("<",55,175,WHITE)
tft.text("OK",145,175,BLACK)
tft.text(">",255,175,WHITE)

tft.show()

while True:
    pass
