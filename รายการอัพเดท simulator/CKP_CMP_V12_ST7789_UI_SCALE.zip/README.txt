Replace only main.py first. Keep the working st7789_pico.py and xpt2046_pico.py from the version that shows full screen.
