CKP/CMP RP2040 ZERO - V15 ULTRA FAST + RESPONSIVE TOUCH
========================================================

Based directly on the working V14 build.
CKP/CMP pattern definitions and pin assignments are unchanged.
Keep your existing touch_cal_st7789_v13.json calibration file.

V15 speed changes
-----------------
1. Added ST7789 show_rect(): only the changed screen rectangle is transmitted.
2. RPM changes transmit only 320x72 instead of the complete 320x240 screen.
3. Pattern LEFT/RIGHT transmits only the changing information area.
4. START/STOP transmits only that button area.
5. TFT stays at the proven 40 MHz SPI clock for reliability.

V15 touch changes
-----------------
1. XPT2046 reads at 2 MHz instead of 1 MHz.
2. Median filtering uses 3 samples instead of 5, reducing touch latency.
3. A median-filtered first touch is accepted immediately; V14 waited for a second stable reading.
4. Button hit areas have a small 5-pixel allowance around the visible button.
5. Release grace increased to 120 ms to tolerate brief T_IRQ flicker.

Upload these 3 files to RP2040 Zero
-----------------------------------
- main.py
- st7789_pico.py
- xpt2046_pico.py

Do NOT delete touch_cal_st7789_v13.json if touch position is already correct.
Hard Reset after upload.

If touch becomes noisy on your wiring, change the XPT2046 baudrate in
xpt2046_pico.py from 2_000_000 back to 1_000_000. All display speed
improvements will remain active.
